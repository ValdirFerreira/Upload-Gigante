﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }



        public async Task<IActionResult> OnPostUploadAsync(List<IFormFile> files)
        {
            long size = files.Sum(f => f.Length);

            foreach (var formFile in files)
            {
                if (formFile.Length > 0)
                {
                    var filePath = Path.GetTempFileName();

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await formFile.CopyToAsync(stream);
                    }
                }
            }

            // Process uploaded files
            // Don't rely on or trust the FileName property without validation.

            return Ok(new { count = files.Count, size });
        }




        [Route("api/myfileupload")]
        [HttpPost]
        public string MyFileUpload()
        {
            var request = HttpContext.Request;
            var filePath = "C:\\temp\\" + request.Headers["filename"];


            var _file = request.Headers["file"];



            //try
            //{
            //    var ms = new MemoryStream(_file.);

            //    using (var file = new System.IO.FileStream(filePath, System.IO.FileMode.Create))
            //    {
            //        byte[] bytes = new byte[file.Length];
            //        file.Read(bytes, 0, (int)file.Length);
            //        ms.Write(bytes, 0, (int)file.Length);
            //    }

            //}
            //catch (Exception EX)
            //{

            //}

            //byte[] buffer = new byte[(int)request.ContentLength];
            //using (MemoryStream ms = new MemoryStream())
            //{
            //    int read;
            //    while ((read = .Read(buffer, 0, buffer.Length)) > 0)
            //    {
            //        ms.Write(buffer, 0, read);
            //    }
            //    return ms.ToArray();
            //}


            //using (var reader = new StreamReader(Request.Body))
            //{
            //    var body = reader.ReadToEnd();
            //}




            using (var fs = new System.IO.FileStream(filePath, System.IO.FileMode.Create))
            {

            }

            var arquivo = HttpContext.Request.Form.Files;

            var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", request.Headers["filename"]);

            using (var stream = new FileStream(path, FileMode.Create))
            {

            }

            return "uploaded";
        }



        public async Task<IActionResult> EnviarArquivo(List<IFormFile> arquivos)
        {
            //retorna a viewdata
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> EnviarArquivo1(List<IFormFile> arquivos)
        {
            //retorna a viewdata
            return RedirectToAction("Index");
        }
        public async Task<IActionResult> EnviarArquivo2(List<IFormFile> arquivos)
        {
            //retorna a viewdata
            return RedirectToAction("Index");
        }



        [HttpPost("Home/UploadFile")]
        [RequestFormLimits(MultipartBodyLengthLimit = long.MaxValue)]
        [RequestSizeLimit(long.MaxValue)]
        public async Task<IActionResult> UploadFile(List<IFormFile> arquivos)
        {


            return RedirectToAction("Index");
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
