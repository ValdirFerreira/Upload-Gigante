﻿


function uploadFile() {
    var xhr = new XMLHttpRequest();
    var file = document.getElementById('myfile').files[0];
    xhr.open("POST", "api/myfileupload");
    xhr.setRequestHeader("filename", file.name);


    var fdata = new FormData();
    var fileInput = $('#fileDemanda')[0];

    fdata.append("fileDemanda", fileInput);

    xhr.setRequestHeader("file", file);

    xhr.send(fdata);
}





function ExecutarImportacao() {

    var url = "/Home/UploadFile";

    var files = $("#fileDemanda").get(0).files[0];


    var formData = new FormData();
    formData.append("file", files);


    var fdata = new FormData();
    var fileInput = $('#fileDemanda')[0];
    var file = fileInput.files[0];
    fdata.append("fileDemanda", file);


    $.ajax({
        url: url,
        type: 'POST',
        data: fdata,

        async: true,
        cache: false,
        contentType: "application/json; charset=utf-8",
        //contentType: 'application/x-www-form-urlencoded',
        enctype: 'multipart/form-data',
        processData: false
        , success: function (data) {

            if (data.success) {
                alert("Sucesso")
            }
            else {
                alert("Erro")
            }
        }
    });



}

function Importa() {

    var url = "/Home/EnviarArquivo";

    //var files = $("#arquivos").get(0).files[0];


    //var formData = new FormData();
    //formData.append("file", files);


    var fdata = new FormData();
    var fileInput = $('#arquivos')[0];
    var file = fileInput.files[0];
    fdata.append("arquivos", file);


    $.ajax({
        url: url,
        type: 'POST',
        data: fdata,

        //async: true,
        //cache: false,
        //contentType: "application/json; charset=utf-8",
        //contentType: 'application/x-www-form-urlencoded',
        enctype: 'multipart/form-data'
        //processData: false
        , success: function (data) {

            if (data.success) {
                alert("Sucesso")
            }
            else {
                alert("Erro")
            }
        }
    });



}



$(function () {
   // $("#btnExecutar").click(function () { Importa(); });
});